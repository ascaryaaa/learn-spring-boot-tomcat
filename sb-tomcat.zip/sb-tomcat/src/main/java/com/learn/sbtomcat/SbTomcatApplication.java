package com.learn.sbtomcat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbTomcatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbTomcatApplication.class, args);
	}

}
